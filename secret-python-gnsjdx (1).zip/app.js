// Initialisation du stockage local
if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
}
if (!localStorage.getItem('deliveries')) {
    localStorage.setItem('deliveries', JSON.stringify([]));
}

function showSection(section) {
    document.getElementById('utilisateurs').style.display = 'none';
    document.getElementById('livraisons').style.display = 'none';
    document.getElementById(section).style.display = 'block';
}

// Gestion des utilisateurs
document.getElementById('userForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const user = {
        nom: document.getElementById('nom').value,
        identifiant: document.getElementById('identifiant').value,
        mot_de_passe: document.getElementById('mot_de_passe').value,
        type: document.getElementById('type').value
    };
    const users = JSON.parse(localStorage.getItem('users'));
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));
    updateUserList();
    this.reset();
});

function updateUserList() {
    const users = JSON.parse(localStorage.getItem('users'));
    const userList = document.getElementById('userList');
    userList.innerHTML = '';
    users.forEach(user => {
        const li = document.createElement('li');
        li.textContent = `${user.nom} (${user.type})`;
        userList.appendChild(li);
    });
}

// Gestion des livraisons
document.getElementById('deliveryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const delivery = {
        adresse: document.getElementById('adresse').value,
        statut: 'En attente'
    };
    const deliveries = JSON.parse(localStorage.getItem('deliveries'));
    deliveries.push(delivery);
    localStorage.setItem('deliveries', JSON.stringify(deliveries));
    updateDeliveryList();
    this.reset();
});

function updateDeliveryList() {
    const deliveries = JSON.parse(localStorage.getItem('deliveries'));
    const deliveryList = document.getElementById('deliveryList');
    deliveryList.innerHTML = '';
    deliveries.forEach(delivery => {
        const li = document.createElement('li');
        li.textContent = `${delivery.adresse} (${delivery.statut})`;
        deliveryList.appendChild(li);
    });
}

// Initialisation des listes
updateUserList();
updateDeliveryList();