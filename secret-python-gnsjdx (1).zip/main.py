import asyncio
from pyodide.http import pyfetch
import micropip
from js import console

async def setup():
    await micropip.install(['flask', 'flask-sqlalchemy', 'werkzeug'])
    
    from flask import Flask, render_template, request, redirect, url_for, session, flash
    from flask_sqlalchemy import SQLAlchemy
    from werkzeug.security import generate_password_hash, check_password_hash
    from functools import wraps

    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///livraison.db'
    app.config['SECRET_KEY'] = 'votre_clé_secrète_ici'  # Changez ceci dans un environnement de production
    db = SQLAlchemy(app)

    # Le reste du code reste inchangé...

    with app.app_context():
        db.create_all()
        # Créer un admin par défaut si aucun n'existe
        if not Admin.query.first():
            admin = Admin(nom='Admin', identifiant='admin', mot_de_passe=generate_password_hash('admin123'))
            db.session.add(admin)
            db.session.commit()

    console.log("Application Flask prête à démarrer")
    return app

asyncio.ensure_future(setup())